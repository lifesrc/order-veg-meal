// const Docxtemplater = window.Docxtemplater
// const PizZip = window.PizZip
// const PizZipUtils = window.PizZipUtils
// const saveAs = window.saveAs

function loadFile(url, callback) {
    PizZipUtils.getBinaryContent(url, callback);
}

loadFile('./tag-example.docx', function (error, content) {
    if (error) {
        throw error
    }
    var zip = new PizZip(content)
    var doc = new Docxtemplater().loadZip(zip)
    doc.setData({
        first_name: 'Johnqaz',
        last_name: 'Doeqaz',
        phone: '0652455478qaz',
        description: 'New Websiteqaz',
        gogogo: 'GoGoGo'
    })
    try {
        // render the document (replace all occurences of {first_name} by John, {last_name} by Doe, ...)
        doc.render()
    } catch (error) {
        // The error thrown here contains additional information when logged with JSON.stringify (it contains a properties object containing all suberrors).
        function replaceErrors(key, value) {
            if (value instanceof Error) {
                return Object.getOwnPropertyNames(value).reduce(function (error, key) {
                    error[key] = value[key]
                    return error
                }, {})
            }
            return value
        }
        console.log(JSON.stringify({ error: error }, replaceErrors))

        if (error.properties && error.properties.errors instanceof Array) {
            const errorMessages = error.properties.errors
                .map(function (error) {
                    return error.properties.explanation
                })
                .join('\n')
            console.log('errorMessages', errorMessages)
            // errorMessages is a humanly readable message looking like this :
            // 'The tag beginning with 'foobar' is unopened'
        }
        throw error
    }
    var out = doc.getZip().generate({
        type: 'blob',
        mimeType: 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
    }) //Output the document using Data-URI
    saveAs(out, 'output.docx')
})
